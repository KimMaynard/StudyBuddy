
package com.example.studybuddy

data class Message(
    val role: String,
    val content: String
)
